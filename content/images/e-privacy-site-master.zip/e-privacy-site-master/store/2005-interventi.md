Title: e-privacy 2005 interventi
Date: 2004-04-03 10:20
Category: 2004
Tags: 2004, eprivacy, interventi
lang: it

---  
![P&ace logo by Flexer](logo_pws_small.jpg) | E-privacy 2005 | ![EPrivacy logo by Flexer](pe2005small.png)  
Data retention: da regola ad eccezione  
|  |  Indice  
---  
  
  


[Home page](index.html)   
  


[Interventi](interventi.html)   
  


[Pws](pws/index.html)   
  


[Edizione](2004/index.html)

[del 2004](2004/index.html)   
  


[Edizione](2003/index.html)

[del 2003](2003/index.html)   
  


[Edizione](2002/index.html)

[del 2002](2002/index.html)   
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
| 

_"La paranoia e' una virtu'." - Anonimo, 1984_

* * *

I documenti delle scorse edizioni di E-privacy sono ancora disponibili: [2004](2004/index.html), [2003](2003/index.html), [2002](2002/index.html). 

* * *

##  _Atti del Convegno._

Causa problemi tecnici,alcune registrazioni non sono disponibili.   
  
**Venerdi 27 Maggio - mattina **   
  
_ Saluto di apertura dei lavori _   
Maria Rosa di Giorgi - Vicepresidente Consiglio Regionale   
audio in formato [ogg](audio/Ep2005_Benvenuto_Di_Giorgi.ogg).   
  
_ Il Progetto Winston Smith - scolleghiamo il Grande Fratello _   
Leandro Noferini - Progetto Winston Smith   
slide in formato [pdf](atti/Ep2005_Il_Progetto_Winston_Smith_Noferini.pdf), [ppt](atti/Ep2005_Il_Progetto_Winston_Smith_Noferini.ppt).   
  
_ Sono le Darknet il futuro della Rete?   
Innovazione e liberta' al confine tra ordine e caos _   
Marco A. Calamari - Progetto Winston Smith   
slide in formato [pdf](atti/Ep2005_Sono_le_Darknet_il_futuro_della_Rete_Calamari.pdf), [Ooo](atti/Ep2005_Sono_le_Darknet_il_futuro_della_Rete_Calamari.sxi); audio in formato [ogg](audio/Ep2005_Sono_le_Darknet_il_futuro_della_Rete_Calamari.ogg).    
  
**Venerdi 27 Maggio - pomeriggio **   
  
_ Tor and Mixminion: Two Practical Deployed Anonymity Networks. _   
Nick Mathewson - The Free Haven Project / EFF (in inglese)   
slide in formato [pdf](atti/Ep2005_Tor_e_Mixminon_%20Mathewson.pdf).   
  
_ Il progetto Privacy-Box; "Vogliamo scatole, non programmi" _   
Gianni Bianchini - Progetto Winston Smith   
slide in formato [pdf](atti/Ep2005_Pbox.pdf).   
  
_ OpenPrivacy - Software Libero a supporto delle PMI per l'adeguamento al d.lgs 196/03 _   
Ivano Greco Firenze Tecnologia - Azienda Speciale della CCIAA di Firenze   
slide in formato [pdf](atti/Ep2005_Openprivacy_Greco.pdf), [Ooo](atti/Ep2005_Openprivacy_Greco.sxi).   
  
**Sabato 28 Maggio - mattina **   
  
_ La responsabilita' civile per danni conseguenti alla raccolta dei dati ed alla loro conservazione _   
avv. Antonino Attanasio - Studio FAS   
slide in formato [pdf](atti/Ep2005_Responsabilita_civile_Attanasio.pdf), [Ooo](atti/Ep2005_Responsabilita_civile_Attanasio.sxi); audio in formato [ ogg](audio/Ep2005_Responsabilita_civile_Attanasio.ogg).   
  
_ PGP luci e ombre: storia e evoluzione dello strumento per la privacy piu' usato al mondo _   
Fabio Pietrosanti - Softpj.org   
slide in formato [pdf](atti/Ep2005_PGP_luci_e_ombre_Pietrosanti.pdf), [ppt](atti/Ep2005_PGP_luci_e_ombre_Pietrosanti.ppt); audio in formato [ogg](audio/Ep2005_PGP_luci_e_ombre_Pietrosanti.ogg).   
  
_ Oggi e' il domani di cui dovevamo preoccuparci ieri:   
una proposta di legge per la regolamentazione di uso, conservazione e cancellazione di dati geo- e crono-referenziati raccolti con mezzi automatici e contenenti identificativi utente univoci. _   
M. A. Calamari, G. Bianchini, A. Glorioso   
slide in formato [pdf](atti/Ep2005_Bileta.pdf), [Ooo](atti/Ep2005_Bileta.sxi),   
slide (in inglese) in formato [pdf](atti/Ep2005_Proposta_legge_inglese.pdf), [ppt](atti/Ep2005_Proposta_legge_inglese.ppt),   
paper completa (in inglese) formato [pdf](atti/Ep2005_Proposta_legge_testo_completo.pdf), [rtf](atti/Ep2005_Proposta_legge_testo_completo.rtf).   
testo della proposta di legge in formato [pdf](atti/Ep2005_Proposta_legge_testo_completo_italiano_v6.pdf), [rtf](atti/Ep2005_Proposta_legge_testo_completo_italiano_v6.rtf),   
audio in formato [ogg](audio/Ep2005_Bileta.ogg).   
  
**Sabato 28 Maggio - pomeriggio **   
  
_ La tutela dei dati personali: profili internazionalistici _   
Nadina Foggetti - Dottoranda presso Università degli Studi di Bari   
slide in formato [pdf](atti/Ep2005_Profili_internazionalistici_Foggetti.pdf), [ppt](atti/Ep2005_Profili_internazionalistici_Foggetti.ppt); audio in formato [ogg](audio/Ep2005_Profili_internazionalistici_Foggetti.ogg).   
  
_ Case history - Bussole con accesso biometrico per una banca sicura, quali problemi per la privacy? _   
Roberto Carbonari e Alessandro La Pietra - Bassnet   
slide in formato [pdf](atti/Ep2005_Biobussole_vs_e-privacy_Bassnet.pdf), [ppt](atti/Ep2005_Biobussole_vs_e-privacy_Bassnet.ppt); parte 1 formato audio [ogg](audio/Ep2005_Biobussole_vs_e-privacy_Bassnet_parte_1.ogg), parte 2 formato audio [ogg](audio/Ep2005_Biobussole_vs_e-privacy_Bassnet_parte_2.ogg).   
  
_ Anonymous Remailer e Pseudonym server Sistemi di comunicazione anonima ad alta latenza _   
Federico Moro - Khamsa   
slide in formato [pdf](atti/Ep2005_Remailer_Moro.pdf); audio in formato [ogg](audio/Ep2005_Remailer_Moro.ogg).   
  
_ Spyware - dalla parte dell'attaccante _   
Matteo G.P Flora - LK Project Security  
Intervento non tenuto per cause di forza maggiore;   
slide disponibili per gentile concessione dell'Autore   
slide in formato [pdf](atti/Ep2005_Spyware_Flora.pdf).   
  
  
---  
---  
  
Questa pagina ed i suoi contenuti sono distribuiti sotto la licenza [Gnu GPL 2 ](COPYING.html)
