Template: event
Title: PROSSIMA EDIZIONE: Dalle Istituzioni alla Blockchain
Date: 2019-04-10 12:00:00
Category: 2019
lang: it
Num: XXVI
Year: 2019
slug: e-privacy-XXVI-prossimaedizione
City: Bari
Where: TBA
When: 3-4 ottobre
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: autunno
previd: 2019
prev: e-privacy-XXV
Xnextid:  2017W
Xnext: e-privacy-XVIII
Organizzatori: pws,hermes
Collaboratori: bba
XSponsor: sepel,sikurezza.org,ush,isgroup,cgt,brat
XPatrocini:
XMediaPartner: infomedia,radioradicale,aneddotica

### <b> e-privacy@Bari </b>

** La prossima edizione di e-privacy si svolgerà a Bari il 3 e 4 ottobre 2019. **

Il tema è:
<br>
** "Dalle Istituzioni alla Blockchain" **
<br>
** <i>Condivisione, fiducia, consenso e delega attraverso la tecnologia in un mondo senza privacy?</i> **
