slug: e-privacy-XXXIII-proposta
XStatus: draft
Template: event
Title: Proposta Talk
Date: 2023-07-15 00:00:00
Category: 2023
lang: it
Num: XXXIII
Year: 2023
City: Pisa
Where: Pisa & Videoconferenza & Streaming
When: 23-24 novembre
Season: winter
previd: 2023S
prev: e-privacy-XXXII
nextid:
next:
Organizzatori: pws, hermes
Collaboratori: 
Patrocini: 
Sponsor: cgt,sikurezza.org,sepel,ush,isgroup
MediaPartner: infomedia,aneddotica,lealternative, hackerjournal
timeline: 20 ottobre | 27 ottobre | 17 novembre

<script type="text/javascript" src="//pws.xed.it/form/generate.js?id=22"></script>
