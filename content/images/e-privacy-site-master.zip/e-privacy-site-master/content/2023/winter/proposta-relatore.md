XStatus: draft
Template: event
Title: Proposta Talk
Date: 2022-07-15 00:00:00
slug: e-privacy-XXXIII-proposta-relatore
Category: 2023
lang: it
Num: XXXIII
Year: 2023
City: Pisa
Where: Pisa & Videoconferenza & Streaming
When: 23-24 novembre
Season: winter
previd: 2023
prev: e-privacy-XXXII
nextid:
next:


Grazie

[Vuoi aggiungere il profilo per un relatore dell'intervento?](/e-privacy-XXXI-proposta-relatore-add.html)

Ricordarti di inserire i profili di tutti i relatori che vuoi vengano riportati sul sito.
