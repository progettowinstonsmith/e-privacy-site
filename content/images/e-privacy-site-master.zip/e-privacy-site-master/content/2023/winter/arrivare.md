slug: e-privacy-XXXIII-come-arrivare
Template: event
XStatus: draft
Title: Come arrivare ad e-privacy
Date: 2023-09-13 12:05:00
Category: 2023
lang: it
Num: XXXIII
Year: 2023
City: PISA
Where: Pisa & Videoconferenza & Streaming
When: 23-34 novembre
Season: winter
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
previd: 2023W
prev: e-privacy-XXXII
nextid:
next:
timeline: 20 ottobre | 27 ottobre | 17 novembre
css: .title-XXXI { font: 25px arial, sans-serif; text-align: center; }   .subtitle-XXXI { font: 18px arial, sans-serif; text-align: center; }


<h2>Dove è la sede? </h2>

Il Convegno si svolgerà presso la sede dell'Ordine degli Ingegneri di Pisa, Via Santa Caterina, 16 - 56127 Pisa 
<br>
<br>
E' in centro, dietro la Scuola Normale, 1,6 km, cioè 23 minuti a piedi dalla stazione ferroviaria.
<br>
<br>
Per chi viene in auto, ci sono parcheggi con parchimetro anche di fronte alla sede, ma sono carissimi. Ce ne sono di meno cari nelle vicinanze, ma trovarli liberi non è facile.
<br>
Se venite in aereo, dall'aereoporto consigliamo il taxi.
<br>
Chi avesse problemi o domande sulla logistica, può contattare la segreteria [segreteria@winstonsmith.org](mailto:segreteria@winstonsmith.org).
<br>
<br>


<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d311.96866116517737!2d10.401996093013487!3d43.72155285217666!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12d591a477324605%3A0x8be010738f692abd!2sVia%20Santa%20Caterina%2C%2016%2C%2056127%20Pisa%20PI!5e0!3m2!1sit!2sit!4v1698578805175!5m2!1sit!2sit" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
<br>
<br>
<img src="/images/sale/ordine_ingegneri_pisa.png">


