slug: e-privacy-XXXII-come-arrivare
Template: event
XStatus: draft
Title: Come arrivare ad e-privacy
Date: 2023-04-29 00:01:00
Category: 2023
lang: it
Num: XXXII
Year: 2023
City: ROMA
Where: Roma
When: 14-15 giugno
Season: summer
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
previd: 2022W
prev: e-privacy-XXXI
nextid:
next:
timeline: 10 maggio | 14 maggio | 12 giugno
css: .title-XXXII { font: 25px arial, sans-serif; text-align: center; }   .subtitle-XXX { font: 18px arial, sans-serif; text-align: center; }


<h2>Dove è la sede</h2>

La sede del Convegno è la sala dell'Associazione Stampa Romana, Piazza della Torretta, 36, 00186 Roma.
<br>
<br>
<br>

<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2969.5119649028875!2d12.474677976138276!3d41.903351763832596!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x132f605151e13eaf%3A0x37c7697a428cf021!2sPiazza%20della%20Torretta%2C%2036%2C%2000186%20Roma%20RM!5e0!3m2!1sit!2sit!4v1683016446798!5m2!1sit!2sit" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
<br>


