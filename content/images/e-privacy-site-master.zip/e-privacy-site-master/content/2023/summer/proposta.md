Template: event
Title: Proposta Talk
slug: e-privacy-XXXII-proposta
Date: 2023-04-29 00:01:00
Category: 2023
lang: it
Num: XXXII
Year: 2023
City: ROMA
Where: Roma
When: 14-15 giugno
Season: summer
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
previd: 2022W
prev: e-privacy-XXXI
nextid:
next:
timeline: 10 maggio | 14 maggio | 12 giugno
css: .title-XXXII { font: 25px arial, sans-serif; text-align: center; }   .subtitle-XXX { font: 18px arial, sans-serif; text-align: center; }


<script type="text/javascript" src="//pws.xed.it/form/generate.js?id=22"></script>
