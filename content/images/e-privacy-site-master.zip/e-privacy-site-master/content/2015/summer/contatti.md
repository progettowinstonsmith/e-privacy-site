Template: event
Title: Contatti
Date: 2015-06-04 10:20
Category: 2015
lang: it
slug: contatti-XVII
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>

# Informazioni di contatto

Il convegno *e-privacy* è organizzato da:

- [Progetto Winston Smith](http://pws.winstonsmith.org)
- [Hermes Center for Transparency and Digital Human Rights](http://logioshermes.org)

PER FAVORE CONTATTATECI ESCLUSIVAMENTE VIA EMAIL ALL'INDIRIZZO

[EPRIVACY@WINSTONSMITH.ORG](mailto:eprivacy@winstonsmith.org)

Solo i relatori

[CFP-EPRIVACY@WINSTONSMITH.ORG](mailto:cfp-eprivacy@winstonsmith.org)

# Luogo della conferenza

<script src='https://maps.googleapis.com/maps/api/js?v=3.exp'></script>
<div style='overflow:hidden;height:448px;width:611px;'><div id='gmap_canvas' style='height:448px;width:611px;'></div>
<style>#gmap_canvas img{max-width:none!important;background:none!important}</style></div>
 <a href='http://www.maps-generator.com/it'>maps-generator.com</a> <script type='text/javascript' src='http://embedmaps.com/google-maps-authorization/script.js?id=0797871d9f258be8c5ce36dfcce0c1025e3011cd'></script><script type='text/javascript'> function init_map(){
var myOptions = {
zoom:13,center:new google.maps.LatLng(41.9014429,12.477100699999937),
mapTypeId: google.maps.MapTypeId.ROADMAP};
map = new google.maps.Map(document.getElementById('gmap_canvas'), myOptions);
marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(41.9014429,12.477100699999937)});
infowindow = new google.maps.InfoWindow({
content:'<strong>e-privacy XVII 2015</strong><br>'+
'Via Campo Marzio, 78<br>'+
'00186 Rome<br>'
});
google.maps.event.addListener(marker, 'click', function(){
infowindow.open(map,marker);
});
infowindow.open(map,marker);
}
google.maps.event.addDomListener(window, 'load', init_map);
</script>

# Seguici online

- Sito web: [e-privacy.winstonsmith.org](http://e-privacy.winstonsmith.org)
- Facebook: [https://www.facebook.com/progetto.winston.smith](https://www.facebook.com/progetto.winston.smith)
<!-- - Gruppo Linkedin: [www.linkedin.com/groups/Progetto-Winston-Smith-1888831/about](http://www.linkedin.com/groups/Progetto-Winston-Smith-1888831/about) -->

