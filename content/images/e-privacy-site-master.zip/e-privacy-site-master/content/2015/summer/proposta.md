Template: event
Title: Proposta Talk
Date: 2015-04-22 10:20
Category: 2015
lang: it
Num: XVII
Year: 2015
slug: e-privacy-XVII-proposta
City: Roma
Where: Nuova Sala dei Gruppi<br/>Camera dei Deputati<br/>Via Campo Marzio, 78
When: 2/3 Luglio
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: estate
oldpage: /materiali/2015
previd: 2014W
prev: e-privacy-XVI

<!-- 
<iframe src="https://docs.google.com/forms/d/1X6nd08wH2HHavKyar-wcL8y1i5pORYUwRHIFBbjPVmA/viewform?embedded=true" width="700" height="900" frameborder="0" marginheight="0" marginwidth="0">Loading...</iframe>
-->
