Template: event
Title: Proposta Talk
Date: 2015-08-28 10:20
Category: 2015
lang: it
Num: XVIII
Year: 2015
slug: e-privacy-XVIII-proposta
City: Cagliari
XWhere: Nuova Sala dei Gruppi<br/>Camera dei Deputati<br/>Via Campo Marzio, 78
When: 16/17 Ottobre
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: autunno
Xoldpage: /materiali/2015
previd: programma
prev: e-privacy-XVIII-programma

<iframe src="https://docs.google.com/forms/d/1X6nd08wH2HHavKyar-wcL8y1i5pORYUwRHIFBbjPVmA/viewform?embedded=true" width="700" height="900" frameborder="0" marginheight="0" marginwidth="0">Loading...</iframe>
