Template: article
Title: Mappa delle edizioni di e-privacy
Date: 2021-04-22 10:20
lang: it
slug: mappa-edizioni-e-privacy
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>

<!-- Usa height="1000px" -->

<p><a href="http://umap.openstreetmap.fr/it/map/eprivacy-3_58511">Visualizza a schermo intero</a></p>
<iframe width="100%" height="1000px" frameBorder="0" allowfullscreen src="http://umap.openstreetmap.fr/it/map/eprivacy-3_58511?scaleControl=true&miniMap=true&scrollWheelZoom=true&zoomControl=true&allowEdit=false&moreControl=false&searchControl=null&tilelayersControl=null&embedControl=null&datalayersControl=true&onLoadPanel=undefined&captionBar=false"></iframe>


<!--

Bisogna modificare questo foglio elettronico qui per aggiornare i dati della mappa


https://ethercalc.org/17whurbqij

-->
