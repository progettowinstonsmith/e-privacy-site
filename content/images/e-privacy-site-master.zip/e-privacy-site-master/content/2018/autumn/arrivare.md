XStatus: draft
Template: event
Date: 2017-07-07 10:20
Category: 2018
lang: it
Num: XXIV
Year: 2018
City: Roma
Where: Campidoglio<br/>Roma
When: 30 novembre - 1 dicembre
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: autunno
previd: CFP
prev: e-privacy-XXIV-cfp
Organizzatori: hermes,pws
Collaboratori: bba
XSponsor: grusp,sikurezza.org,ush,puntoi
XPatrocini: comlucca
XMediaPartner: infomedia,radioradicale
Title: Come arrivare ad eprivacy
slug: e-privacy-XXIV-come-arrivare

##Sede di svolgimento:

La “Sala del Carroccio” si trova in piazza del Campidoglio nel Palazzo Senatorio (il palazzo
del Sindaco).

Per chi arriva in taxi, può farsi portare fino a Via San Pietro in
Carcere e da li salire al Campidoglio, una volta arrivati in cima si
arriva direttamente alle scale per la sala.

<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2969.986878568344!2d12.480257715441574!3d41.893139279220996!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x132f604c9b68c939%3A0xa560a5d14750a8e3!2sSala+Del+Carroccio!5e0!3m2!1sit!2sit!4v1473830966297" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>

# In autobus

Per chi arriva alla stazione Termini, prende l’autobus dall’antistante Piazza dei
Cinquecento:

- Linea 170 Linea 170 Linea 170 – Scendere alla fermata “Teatro Marcello”
- Linea 85 Linea 85 Linea 85 – Scendere alla fermata “Piazza Venezia”

in entrambi i casi proseguire a piedi e salire la scalinata del Campidoglio. In cima si
giungerà di fronte al Palazzo Senatorio, le scale per salire alla sala sono a lato sulla
sinistra. Le scale sono strette e contraddistinte da una colonna con una lupa in cima.

<iframe src="https://www.google.com/maps/embed?pb=!1m28!1m12!1m3!1d11878.391281538907!2d12.482450528135717!3d41.90150568841525!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m13!3e3!4m5!1s0x132f61a439c0ffef%3A0xa4307dbef261a994!2sStazione+Termini%2C+Piazza+dei+Cinquecento%2C+Roma%2C+RM!3m2!1d41.9009273!2d12.5022603!4m5!1s0x132f604c9b68c939%3A0xa560a5d14750a8e3!2sSala+Del+Carroccio%2C+Piazza+del+Campidoglio%2C+00186+Roma!3m2!1d41.8931393!2d12.482446399999999!5e0!3m2!1sit!2sit!4v1473831119738" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>


# A piedi

<iframe src="https://www.google.com/maps/embed?pb=!1m28!1m12!1m3!1d11878.91209008647!2d12.483598578134098!3d41.898705939119075!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m13!3e2!4m5!1s0x132f61a439c0ffef%3A0xa4307dbef261a994!2sStazione+Termini%2C+Piazza+dei+Cinquecento%2C+Roma%2C+RM!3m2!1d41.9009273!2d12.5022603!4m5!1s0x132f604c9b68c939%3A0xa560a5d14750a8e3!2sSala+Del+Carroccio%2C+Piazza+del+Campidoglio%2C+00186+Roma!3m2!1d41.8931393!2d12.482446399999999!5e0!3m2!1sit!2sit!4v1473831168345" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
