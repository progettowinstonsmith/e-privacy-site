XStatus: draft
slug: e-privacy-XXIV-proposta
Title: Proposta Talk
Template: event
Date: 2017-07-07 10:20
Category: 2018W
lang: it
Num: XXIV
Year: 2018
City: Roma
Where: Campidoglio<br/>Roma
When: 30 novembre - 1 dicembre
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: autunno
previd: 2018
prev: e-privacy-XXIII


<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSd6_7uV7nr9HXiL-R7jG9V8qXZvbDH2CJq0ci42pLj-9nSrSw/viewform" width="700" height="800" frameborder="0" marginheight="0" marginwidth="0">Caricamento in corso...</iframe>
