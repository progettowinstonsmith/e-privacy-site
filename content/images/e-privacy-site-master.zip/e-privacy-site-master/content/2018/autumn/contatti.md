XStatus: draft
Title: Contatti
slug: contatti-XXIV
Template: event
Date: 2017-06-04 10:20
Category: 2018
Num: XXIV
Year: 2018
City: Roma
Where: Campidoglio<br/>Roma
When: 30 novembre - 1 dicembre
lang: it
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>

# Informazioni di contatto

Il convegno *e-privacy* è organizzato da:

- [Progetto Winston Smith](http://pws.winstonsmith.org)
- [Hermes Center for Transparency and Digital Human Rights](http://logioshermes.org)

PER FAVORE CONTATTATECI ESCLUSIVAMENTE VIA EMAIL ALL'INDIRIZZO

[eprivacy@winstonsmith.org](mailto:eprivacy@winstonsmith.org)

Solo i relatori 

[cfp-eprivacy@winstonsmith.org](mailto:cfp-eprivacy@winstonsmith.org)

# Luogo della conferenza

<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2969.986878568344!2d12.480257715441574!3d41.893139279220996!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x132f604c9b68c939%3A0xa560a5d14750a8e3!2sSala+Del+Carroccio!5e0!3m2!1sit!2sit!4v1473830966297" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>


# Seguici online

- Sito web: [e-privacy.winstonsmith.org](http://e-privacy.winstonsmith.org)
<!-- - Pagina Facebook: [www.facebook.com/events/120596381605441](http://www.facebook.com/events/120596381605441) -->
- Gruppo Linkedin: [https://www.linkedin.com/groups/1888831/](https://www.linkedin.com/groups/1888831/)

