XStatus: draft
Title: Come arrivare ad e-privacy
Date: 2018-02-22 10:20
Category: 2018
lang: it
Num: XXIII
Year: 2018
slug: e-privacy-XXIII-come-arrivare
City: Bologna
Where: Biblioteca Salaborsa<br/>Palazzo d'Accursio, Piazza Nettuno 3
When: 8-9 GiugnoSlogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: estate
previd: 2017W
prev: e-privacy-XXII
Xnextid: 2015W
Xnext: e-privacy-XVIII


Sede di svolgimento:

Comune di Bologna
Biblioteca Salaborsa

Piazza Nettuno, 3
40124 Bologna

tel 0512194400
fax 0512194420

Informazioni:
tel 0512194400
lun 14.30-20
mar-ven 10-20

e-mail: bibliotecasalaborsa@comune.bologna.it

<h2>Servizi Pubblici</h2>

<p><strong>Informazioni turistiche:<br /></strong>
Per informazioni e prenotazioni &egrave; attivo il servizio online dell'<strong><a href="http://www.bolognawelcome.com/informazioni-turistiche//" target="_blank" title="APT Bologna">Agenzia di Promozione Turistica</a></strong>.</p>

<p><strong>Trasporto pubblico</strong>
<br>
I parcheggi e l'immediata periferia sono collegati tramite navetta, il resto della Provincia &egrave; collegato con servizio bus.


<h2>Come arrivare in treno</h2>


<iframe src="https://www.google.com/maps/embed?pb=!1m28!1m12!1m3!1d11382.91352925165!2d11.334835638837605!3d44.500232065620324!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m13!3e2!4m5!1s0x477fd49ebfab350f%3A0xceb69b8aad3e1190!2sStazione+Bologna+Centrale%2C+Piazza+Maggiore%2C+Bologna%2C+BO!3m2!1d44.5059073!2d11.3433694!4m5!1s0x477fd4bfc278adc1%3A0xc266fcbe4097cdfd!2sBiblioteca+Salaborsa%2C+Piazza+del+Nettuno%2C+3%2C+40124+Bologna+BO!3m2!1d44.494727999999995!2d11.3418228!5e0!3m2!1sit!2sit!4v1519410413011" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>




