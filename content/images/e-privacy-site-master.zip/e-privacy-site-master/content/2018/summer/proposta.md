Template: event
Title: Proposta Talk
Date: 2017-03-21 10:20
Category: 2018
lang: it
Num: XXIII
Year: 2018
slug: e-privacy-XXIII-proposta
City: Bologna
Where: Biblioteca Salaborsa<br/>Palazzo d'Accursio, Piazza Nettuno 3
When: 8-9 Giugno
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: estate
previd: CFP
prev: e-privacy-XXIII-cfp


<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSeKXyu_lr7X52X82fy6zZCMLlFaks9IuF4FPGgudw3K7gDT5A/viewform?embedded=true" width="700" height="800" frameborder="0" marginheight="0" marginwidth="0">Caricamento in corso...</iframe>

