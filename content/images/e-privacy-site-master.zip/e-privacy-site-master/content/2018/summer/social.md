Title: Attività sociali
Date: 2018-05-21 10:20
Category: 2018
lang: it
Num: XXIII
Year: 2018
slug: e-privacy-XXIII-social
City: Bologna
Where: Biblioteca Salaborsa<br/>Palazzo d'Accursio, Piazza Nettuno 3 
When: 8-9 Giugno
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: estate
previd: 2017W
prev: e-privacy-XXII
Xnextid: 2016W
Xnext: e-privacy-XVIII

Non è stato ancora comunicato nulla. Torna su questa pagina tra qualche giorno.
