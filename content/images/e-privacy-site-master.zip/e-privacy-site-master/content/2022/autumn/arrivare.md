slug: e-privacy-XXXI-come-arrivare
Template: event
XStatus: draft
Title: Come arrivare ad e-privacy
Date: 2022-07-29 00:01:00
Category: 2022
lang: it
Num: XXXI
Year: 2022
City: ROMA | RETE
Where: Roma & Videoconferenza & Streaming
When: 29-30 settembre
Season: autumn
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
previd: 2022S
prev: e-privacy-XXX
nextid:
next:
Organizzatori: pws, hermes
Collaboratori: roma3, masterroma3
Patrocini: gpdp
Sponsor: cgt,sikurezza.org,sepel,ush,isgroup
MediaPartner: infomedia,aneddotica,lealternative, hackerjournal
timeline: 7 settembre | 10 settembre | 25 settembre
css: .title-XXXI { font: 25px arial, sans-serif; text-align: center; }   .subtitle-XXXI { font: 18px arial, sans-serif; text-align: center; }


<h2>Dove è la sede</h2>

La sede del Convegno è l'Aula Magna del Dipartimento di Giurisprudenza dell'Università degli Studi Roma Tre, in via Ostiense, 163 Roma 
(<a href="https://www.openstreetmap.org/search?query=Via%20Ostiense%2C%20163%20Roma#map=18/41.86185/12.47917">Mappa</a>
, <a href="https://www.uniroma3.it/">Sito di Ateneo</a>).
<br>
<br>

