XStatus: draft
Template: event
Title: Proposta Talk
Date: 2022-07-15 00:00:00
slug: e-privacy-XXXI-proposta-relatore
Category: 2022
lang: it
Num: XXXI
Year: 2022
City: Roma & ONLINE
Where: Roma & Videoconferenza & Streaming
When: 29-30 settembre
Season: summer
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
previd: 2022S
prev: e-privacy-XXX


Grazie

[Vuoi aggiungere il profilo per un relatore dell'intervento?](/e-privacy-XXXI-proposta-relatore-add.html)

Ricordarti di inserire i profili di tutti i relatori che vuoi vengano riportati sul sito.
