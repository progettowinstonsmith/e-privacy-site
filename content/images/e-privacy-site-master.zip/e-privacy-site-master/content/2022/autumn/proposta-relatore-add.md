Template: event
Title: Proposta Talk
Date: 2022-03-15 00:00:00
slug: e-privacy-XXXI-proposta-relatore-add
Category: 2022
lang: it
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Num: XXXI
Year: 2022
City: Roma & ONLINE
Where: Roma & Videoconferenza & Streaming
When: 29-30 settembre
Season: autumn
previd: 2022S
prev: e-privacy-XXX
nextid:
next:


<script type="text/javascript" src="//pws.xed.it/form/generate.js?id=23"></script>
