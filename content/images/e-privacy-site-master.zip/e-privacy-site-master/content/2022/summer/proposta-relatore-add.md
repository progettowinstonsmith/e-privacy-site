Template: event
Title: Proposta Talk
Date: 2022-03-15 00:00:00
slug: e-privacy-XXX-proposta-relatore-add
Category: 2022
lang: it
Num: XXX
Year: 2022
City: Firenze & ONLINE
Where: Videoconferenza & Streaming
When: 16-17 giugno
Season: summer
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
previd: 2021W
prev: e-privacy-29e3quarti


<script type="text/javascript" src="//pws.xed.it/form/generate.js?id=23"></script>
