Template: article
Title: Contatti
Date: 2021-03-15 00:00:00
slug: contatti
Category: pagine
lang: it
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>

# Informazioni di contatto

Il convegno *e-privacy* è organizzato da:

- [Progetto Winston Smith](http://pws.winstonsmith.org)

PER FAVORE CONTATTATECI ESCLUSIVAMENTE VIA EMAIL ALL'INDIRIZZO

[eprivacy@winstonsmith.org](mailto:eprivacy@winstonsmith.org)

Solo i relatori

[cfp-eprivacy@winstonsmith.org](mailto:cfp-eprivacy@winstonsmith.org)



# Seguici online

- Sito web di Winston Smith: [www.winstonsmith.org](http://www.winstonsmith.org)

- Sito web e-privacy: [e-privacy.winstonsmith.org](http://e-privacy.winstonsmith.org)

- Sito web Progetto Winston Smith: [pws.winstonsmith.org](http://pws.winstonsmith.org)

- Sito web Big Brother Awards Italia: [bba.winstonsmith.org](http://bba.winstonsmith.org)

<!-- - Pagina Facebook: [www.facebook.com/events/120596381605441](http://www.facebook.com/events/120596381605441) -->

- Pagina Twitter: [https://twitter.com/eprivacy](https://twitter.com/eprivacy)

- Gruppo Linkedin: [https://www.linkedin.com/groups/1888831/](https://www.linkedin.com/groups/1888831/)
