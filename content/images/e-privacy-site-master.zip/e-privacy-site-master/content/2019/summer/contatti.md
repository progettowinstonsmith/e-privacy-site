Template: event
Title: Contatti
Date: 2019-01-26 12:00:00
Category: 2019
lang: it
slug: contatti-XXV
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>

# Informazioni di contatto

Il convegno *e-privacy* è organizzato da:

- [Progetto Winston Smith](http://pws.winstonsmith.org)
- [Hermes Center for Transparency and Digital Human Rights](http://hermescenter.org)

PER FAVORE CONTATTATECI ESCLUSIVAMENTE VIA EMAIL ALL'INDIRIZZO

[EPRIVACY@WINSTONSMITH.ORG](mailto:eprivacy@winstonsmith.org)

Solo i relatori

[CFP-EPRIVACY@WINSTONSMITH.ORG](mailto:cfp-eprivacy@winstonsmith.org)



# Seguici online

- Sito web: [e-privacy.winstonsmith.org](http://e-privacy.winstonsmith.org)
<!-- - Pagina Facebook: [www.facebook.com/events/120596381605441](http://www.facebook.com/events/120596381605441) -->
- Pagina Twitter: [https://twitter.com/eprivacy](https://twitter.com/eprivacy)
- Gruppo Linkedin: [www.linkedin.com/groups/Progetto-Winston-Smith-1888831/about](http://www.linkedin.com/groups/Progetto-Winston-Smith-1888831/about)
