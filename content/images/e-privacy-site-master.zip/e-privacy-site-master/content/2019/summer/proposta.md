Template: event
Title: Proposta Talk
Date: 2019-01-26 12:00:00
Category: 2019
lang: it
Num: XXV
Year: 2019
slug: e-privacy-XXV-proposta
City: Torino
Where: Aula Ciminiera<br/>Politecnico di Torino
When: 6-7 giugno
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: estate
previd: 2018W
prev: e-privacy-XXIV


<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSeHWsf7jjI_0c5zbRDK7padoMEYIz-ZmpRzBzQcGqrBlpjzNQ/viewform?embedded=true" width="700" height="800" frameborder="0" marginheight="0" marginwidth="0">Caricamento in corso...</iframe>
