Template: event
Title: Upload slides
Date: 2019-01-26 12:00:00
Category: 2019
lang: it
Num: XXV
Year: 2019
slug: e-privacy-XXV-upload
City: Torino
Where: Aula Ciminiera<br/>Politecnico di Torino
When: 6-7 giugno
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: estate
previd: 2018W
prev: e-privacy-XXIV


Per caricare le slides è necessario usare [questo form](https://script.google.com/macros/s/AKfycbynQ-F5MLra2McR8pKSR7CbOMr4RaeeUwfMEGL4_Q/exec) con la password fornita ai relatori.
