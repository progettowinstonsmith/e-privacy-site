Status: Draft
Title: Attività sociali
Date: 2019-01-26 12:00:00
Category: 2019
lang: it
Num: XXVII
Year: 2019
slug: e-privacy-XXVI-social
City: Bari
Where: Biblioteca dell'Ordine<br/>degli Avvocati di Bari
When: 3-4 ottobre
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: autunno
previd: 2018W
prev: e-privacy-XXIV
Xnextid: 2016W
Xnext: e-privacy-XVIII

Non è stato ancora comunicato nulla. Torna su questa pagina tra qualche giorno.
