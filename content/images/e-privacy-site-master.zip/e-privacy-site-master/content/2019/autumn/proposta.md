Template: event
Title: Proposta Talk
Date: 2019-06-26 12:00:00
Category: 2019
lang: it
Num: XXVI
Year: 2019
slug: e-privacy-XXVI-proposta
City: Bari
Where: Biblioteca dell'Ordine<br/>degli Avvocati di Bari
When: 3-4 ottobre
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: autunno
previd: 2019
prev: e-privacy-XXV


<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSexNkPwLTJ7fIai3CIjQb1ej0K88wcKeLzvMPgNxPdZwjZWsg/viewform?embedded=true" width="700" height="1600" frameborder="0" marginheight="0" marginwidth="0">Caricamento in corso...</iframe>
