XStatus: draft
Title: Come arrivare ad e-privacy
Date: 2019-06-26 12:00:00
Category: 2019
lang: it
slug: e-privacy-XXVI-come-arrivare
Num: XXVI
Year: 2019
City: Bari
Where: Biblioteca dell'Ordine<br/>degli Avvocati di Bari
When: 3-4 ottobre
Season: autunno
previd: 2019
prev: e-privacy-XXV
Xnextid: 2015W
Xnext: e-privacy-XVIII


<h2>Sede di e-privacy XXVI</h2>
 
Biblioteca dell'Ordine degli Avvocati di Bari
<br>
VI piano, Palazzo di Giustizia, 
<br>
Piazza Enrico De Nicola 1
<br>
70123 - Bari  
<br>

<h2>Dove e' la sede</h2>

<iframe src="https://www.google.com/maps/d/embed?mid=14eZC_QBuXh4peMGou4En1IrhW7Q&hl=it" width="640" height="480"></iframe>
<br>

