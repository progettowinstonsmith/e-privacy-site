Template: article
Title: Soggettario Controllato del Progetto Winston Smith
Date: 2015-04-22 10:20
Category: generale
lang: it
slug: soggettario
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>


| Soggetto                                |
|-----------------------------------------|
| Affidabilita'                           |
| Algoritmi                               |
| Anonimato                               |
| Blockchain                              |
| Crittografia                            |
| Diritto alla Conoscenza                 |
| Droni                                   |
| eDemocracy                              |
| eGovernment                             |
| Etica                                   |
| Giustizia predittiva                    |
| Informazione                            |
| Intelligenza Artificiale                |
| Privacy                                 |
| Pubblica Amministrazione                |
| Realtà aumentata, virtuale e multiversi |
| Smart City                              |
| Tecnocontrollo                          |

I 	e-privacy 2002 I 		-
II 	e-privacy 2003 II 		-
III 	e-privacy 2004 III 		-
IV 	e-privacy 2005 IV 		-
V 	e-privacy 2006 V 		-
VI 	e-privacy 2007 VI 		-
VII 	e-privacy 2008 VII 		-
VIII 	e-privacy 2009 VIII 		-
IX 	e-privacy 2010 IX 		-
X 	e-privacy 2011 X 		-
XI 	e-privacy 2012 spring XI 		-
XII 	e-privacy 2012 autumn XII 		-
XIII 	e-privacy 2013 spring XIII 		-
XIV 	e-privacy 2013 autumn XIV 		-
XV 	e-privacy 2014 spring XV 		-
XVI 	e-privacy 2014 autumn XVI 		-
XVII 	e-privacy 2015 spring XVII 		-
XVIII 	e-privacy 2015 autumn XVIII 		-
XIX 	e-privacy 2016 spring XIX 		-
XX 	e-privacy 2016 autumn XX 		-
XXI 	e-privacy 2017 summer XXI 		-
XXII 	e-privacy 2017 autumn XXII 		-
XXIII 	e-privacy 2018 summer XXIII 		-
XXIV 	e-privacy 2018 winter XXIV 		-
XXV 	e-privacy 2019 summer XXV 		-
XXVI 	e-privacy 2019 winter XXVI 		18
XXVII 	e-privacy 2020 summer XXVII 		13
XXVIII 	e-privacy 2020 autumn XXVIII 		19
XXIX 	e-privacy 2021 summer XXIX 		23
3.1416 	e-privacy 2016 lab 3.1416 		-
29e¾ 	e-privacy 2021 autumn 29e¾
