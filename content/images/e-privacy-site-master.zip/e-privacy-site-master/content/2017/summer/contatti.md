Status: Draft
Template: event
Title: Contatti
Date: 2017-06-04 10:20
Category: 2015
lang: it
slug: contatti-XXI
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>

# Informazioni di contatto

Il convegno *e-privacy* è organizzato da:

- [Progetto Winston Smith](http://pws.winstonsmith.org)
- [Hermes Center for Transparency and Digital Human Rights](http://logioshermes.org)

PER FAVORE CONTATTATECI ESCLUSIVAMENTE VIA EMAIL ALL'INDIRIZZO

[EPRIVACY@WINSTONSMITH.ORG](mailto:eprivacy@winstonsmith.org)

Solo i relatori

[CFP-EPRIVACY@WINSTONSMITH.ORG](mailto:cfp-eprivacy@winstonsmith.org)

# Luogo della conferenza

<script src='https://maps.googleapis.com/maps/api/js?v=3.exp'></script><div style='overflow:hidden;height:400px;width:520px;'><div id='gmap_canvas' style='height:400px;width:520px;'></div><style>#gmap_canvas img{max-width:none!important;background:none!important}</style></div> <a href='http://maps-generator.com/it'>maps generator</a> <script type='text/javascript' src='https://embedmaps.com/google-maps-authorization/script.js?id=da1559695906f950e64b13dce3edce4c80f33d36'></script><script type='text/javascript'>function init_map(){var myOptions = {zoom:14,center:new google.maps.LatLng(43.7228386,10.401688799999988),mapTypeId: google.maps.MapTypeId.ROADMAP};map = new google.maps.Map(document.getElementById('gmap_canvas'), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(43.7228386,10.401688799999988)});infowindow = new google.maps.InfoWindow({content:'<strong>e-privacy 2016</strong><br>Polo didattico Piagge Università degli Studi di Pisa<br>56100 Pisa<br>'});google.maps.event.addListener(marker, 'click', function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, 'load', init_map);</script>


# Seguici online

- Sito web: [e-privacy.winstonsmith.org](http://e-privacy.winstonsmith.org)
- Pagina Facebook: [www.facebook.com/events/120596381605441](http://www.facebook.com/events/120596381605441)
- Gruppo Linkedin: [www.linkedin.com/groups/Progetto-Winston-Smith-1888831/about](http://www.linkedin.com/groups/Progetto-Winston-Smith-1888831/about)

