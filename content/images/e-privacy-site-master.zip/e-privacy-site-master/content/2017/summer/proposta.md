Template: event
Title: Proposta Talk
Date: 2017-03-21 10:20
Category: 2017
lang: it
Num: XXI
Year: 2017
slug: e-privacy-XXI-proposta
City: Lucca
Where: Real Collegio<br/>P.zza del Collegio, 13
When: 23-24 Giugno
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: estate
previd: 2016W
prev: e-privacy-XX


<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSeuRUSpctzp8DFLEVfanQDa3V6H6R1dCovqDCMYBw-qfjzjcQ/viewform?embedded=true" width="700" height="800" frameborder="0" marginheight="0" marginwidth="0">Caricamento in corso...</iframe>
