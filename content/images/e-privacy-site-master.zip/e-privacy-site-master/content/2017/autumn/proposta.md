Template: event
Title: Proposta Talk
Date: 2017-07-07 10:20
Category: 2017W
lang: it
Num: XXII
Year: 2017
slug: e-privacy-XXII-proposta
City: Venezia
Where: Corte d'Assise<br/>Tribunale di Rialto
When: 13-14 Ottobre
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: autunno
previd: 2017
prev: e-privacy-XXI


<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSdUeWNtjSDbdczB6gA1lvs6JjUD6Squ8KfDDBmGfdhieOpemw/viewform?embedded=true" width="700" height="800" frameborder="0" marginheight="0" marginwidth="0">Caricamento in corso...</iframe>
