Template: event
Date: 2017-07-07 10:20
Category: 2017
lang: it
Num: XXII
Year: 2017
City: Venezia
Where: Corte d'Assise<br/>Tribunale di Rialto
When: 13-14 Ottobre
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: autunno
previd: 2017
prev: e-privacy-XXII-come-arrivare
Organizzatori: hermes,pws
Collaboratori: bba
XSponsor: grusp,sikurezza.org,ush,puntoi
XPatrocini: comlucca
XMediaPartner: infomedia,radioradicale
Title: Come arrivare ad eprivacy
slug: e-privacy-XXII-come-arrivare

Sede di svolgimento:


La sede di e-privacy 2017 autumn edition sarà l'Aula d'Assise del
Tribunale di Rialto a Venezia.

Il Tribunale di Venezia ha sede in Sestiere San Polo 119, come illustrato nella mappa sottostante:

Piazzale Roma è il punto di interscambio tra mezzi su gomma (autovetture e autobus) e mezzi acquei. 
Il Tribunale, Sede di Rialto, è raggiungibile da Piazzale Roma con il vaporetto linea 1) fermata "Mercato" oppure con la linea 2) fermata "Rialto".


<iframe src="https://www.google.com/maps/embed?pb=!1m28!1m12!1m3!1d5599.016086072196!2d12.32375632567711!3d45.439417494445834!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m13!3e2!4m5!1s0x477eb1c7511cd1f1%3A0xfc7c01f280ca9309!2sStazione+di+Venezia+Santa+Lucia%2C+30100+Venezia+VE%2C+Italy!3m2!1d45.4410697!2d12.3210436!4m5!1s0x477eb1db9fa9d6bf%3A0x714fe84e1b5dbb7e!2sTribunale+Ordinario+di+Venezia%2C+Ruga+dei+Oresi%2C+120%2C+30125+Venezia+VE%2C+Italy!3m2!1d45.4388852!2d12.3352238!5e0!3m2!1sen!2sus!4v1504217277540" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>


<!--
<h2>Servizi Pubblici</h2>

<p><strong>Informazioni turistiche:<br /></strong>Per informazioni e prenotazioni &egrave; attivo il servizio online dell'<strong><a href="http://www.luccatourist.it/" target="_blank" title="APT Lucca">Agenzia di Promozione Turistica</a></strong>.</p>

<p><strong>Parcheggi a Lucca:</strong><br />Sia in prossimit&agrave; del centro storico, sia in alcune zone interne alle mura, &egrave; possibile trovare un'offerta pressoch&eacute; infinita di possibilit&agrave; per lasciare la propria auto.<br />I camper hanno accesso all'area comunale di viale Luporini e all'area privata <strong><a href="http://www.camperilserchio.it" target="_blank" title="Area Camper Il Serchio">Il Serchio</a></strong>.<br /><em>Per una mappa completa dei parcheggi &egrave; possibile consultare il sito di <strong><a href="http://www.metrosrl.it/" target="_blank" title="Parcheggi a Lucca - ">Metro</a></strong>.</em></p>

<p><strong>Trasporto pubblico lucchese:</strong><br />I parcheggi e l'immediata periferia sono collegati tramite navetta, il resto della Provincia &egrave; collegato con servizio bus. In particolare, la zona del Real Collegio &egrave; servita dalle navette 1 e 2.<br /><em>per informazioni su linee, orari e percorsi consultare il sito di <strong><a href="http://www.vaibus.it/" target="_blank" title="Trasporto pubblico lucchese">Vaibus</a></strong>.</em><br /><br /><strong>Treni:</strong><br />La stazione di Lucca &egrave; a 20 minuti di passeggiata dal Real Collegio, per consultare l'orario dei treni &egrave; disponibile il sito di <strong><a href="http://www.trenitalia.com/" target="_blank" title="Ferrovie dello Stato">Trenitalia</a></strong><br /><br /><strong>Autostrade:</strong><br />I caselli di Lucca Est e Lucca Ovest sono prossimi al centro storico. Tariffe e itinerari sul sito di <strong><a href="http://www.autostrade.it/" target="_blank" title="Autostrade per l'Italia">Autostrade per l'Italia</a></strong>.<br /><br /><strong>Aeroporti:</strong><br />Il piccolo <strong><a href="http://www.aeroportoluccatassignano.it/" target="_blank" title="Aeroporto di Lucca-Tassignano">aeroporto di Tassignano</a></strong>, attrezzato per voli turistici, si trova a 20 minuti di automobile dalla citt&agrave;. Gli scali internazionali di <strong><a href="http://www.pisa-airport.com/" target="_blank" title="Aeroporto Galilei di Pisa">Pisa</a></strong> e <strong><a href="http://www.aeroporto.firenze.it/IT/index.php" target="_blank" title="Aeroporto di Firenze">Firenze</a></strong> sono ben collegati via bus e treno.</p>



# In autobus

<iframe src="https://www.google.com/maps/embed?pb=!1m26!1m12!1m3!1d10146.679156239647!2d10.496938182041198!3d43.84255654216743!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m11!3e3!4m5!1s0x12d5847526c1d879%3A0x89fe55018409175e!2sStazione+di+Lucca%2C+Viale+Camillo+Benso+Cavour%2C+Lucca%2C+LU%2C+Italia!3m2!1d43.8374125!2d10.5061477!4m3!3m2!1d43.846565!2d10.503905!5e1!3m2!1sit!2sus!4v1495386742773" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>

# A piedi

<iframe src="https://www.google.com/maps/embed?pb=!1m26!1m12!1m3!1d5073.39125093735!2d10.499577825452299!3d43.84194890468592!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m11!3e2!4m5!1s0x12d5847526c1d879%3A0x89fe55018409175e!2sStazione+di+Lucca%2C+Viale+Camillo+Benso+Cavour%2C+Lucca%2C+LU%2C+Italia!3m2!1d43.8374125!2d10.5061477!4m3!3m2!1d43.846565!2d10.503905!5e1!3m2!1sit!2sus!4v1495386682733" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>

-->
