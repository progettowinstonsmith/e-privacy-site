Template: event
Title: Contatti
Date: 2017-06-04 10:20
Category: 2017
lang: it
slug: contatti-XXII
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>

# Informazioni di contatto

Il convegno *e-privacy* è organizzato da:

- [Progetto Winston Smith](http://pws.winstonsmith.org)
- [Hermes Center for Transparency and Digital Human Rights](http://logioshermes.org)

PER FAVORE CONTATTATECI ESCLUSIVAMENTE VIA EMAIL ALL'INDIRIZZO

[EPRIVACY@WINSTONSMITH.ORG](mailto:eprivacy@winstonsmith.org)

Solo i relatori

[CFP-EPRIVACY@WINSTONSMITH.ORG](mailto:cfp-eprivacy@winstonsmith.org)

# Luogo della conferenza

<iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d5599.014608621026!2d12.323756325167354!3d45.43943238333451!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1stribunale+di+venezia+sestiere+san+polo+119%2C+30125+venezia!5e0!3m2!1sen!2sus!4v1504205480877" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>


# Seguici online

- Sito web: [e-privacy.winstonsmith.org](http://e-privacy.winstonsmith.org)
- Pagina Facebook: [www.facebook.com/events/120596381605441](http://www.facebook.com/events/120596381605441)
- Gruppo Linkedin: [www.linkedin.com/groups/Progetto-Winston-Smith-1888831/about](http://www.linkedin.com/groups/Progetto-Winston-Smith-1888831/about)

