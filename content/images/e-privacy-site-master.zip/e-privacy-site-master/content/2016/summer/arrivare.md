Title: Come arrivare ad eprivacy
Date: 2016-04-29 10:20
Category: 2016
lang: it
Num: XIX
Year: 2016
slug: e-privacy-XIX-come-arrivare
City: Pisa
Where: Polo didattico Piagge<br/>Università degli Studi di Pisa
When: 24-25 Giugno
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: estate
previd: 2015W
prev: e-privacy-XVIII
Xnextid: 2015W
Xnext: e-privacy-XVIII


Sede di svolgimento

Aula del “Polo Didattico Piagge”
via Matteotti - Pisa

In auto:  

* Navigatore: lat=43.720 lon=10.4233
* Autostrade: 
  * A12 Genova-Rosignano: uscita Pisa Centro
  * A11 Firenze Pisa Nord: uscita in corrispondenza del raccordo con l'A12 
* Superstrade: 
  * Firenze-Pisa-Livorno: uscita Pisa Nord-est 

In città: 
* Seguire le indicazioni  per Palazzo dei Congressi

In areo e in treno: 
* dall' Aereoporto Galilei e dalla stazione di Pisa C.le si  può raggiungere il polo Didattico con il taxi (radiotaxi - 050541600) e con i  mezzi pubblici


# In autobus

<iframe src="https://www.google.com/maps/embed?pb=!1m28!1m12!1m3!1d5768.113405834022!2d10.401347724741976!3d43.70937067187895!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m13!3e3!4m5!1s0x12d5919cee976919%3A0xe7e65ce35fbcf669!2sPisa+Central+Station%2C+Piazza+della+Stazione%2C+56125+Pisa+PI%2C+Italy!3m2!1d43.708449099999996!2d10.398468399999999!4m5!1s0x12d59193efe7c6b9%3A0x37a0754cbaa4f0a9!2sPolo+Didattico+delle+Piagge%2C+Via+Giacomo+Matteotti%2C+11%2C+56124+Pisa+PI%2C+Italy!3m2!1d43.7102769!2d10.412346099999999!5e0!3m2!1sen!2sit!4v1465064825094" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>

# A piedi

<iframe src="https://www.google.com/maps/embed?pb=!1m28!1m12!1m3!1d5767.95736600162!2d10.400934974742245!3d43.710992071668926!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m13!3e2!4m5!1s0x12d5919cee976919%3A0xe7e65ce35fbcf669!2sPisa+Central+Station%2C+Piazza+della+Stazione%2C+56125+Pisa+PI%2C+Italy!3m2!1d43.708449099999996!2d10.398468399999999!4m5!1s0x12d59193efe7c6b9%3A0x37a0754cbaa4f0a9!2sPolo+Didattico+delle+Piagge%2C+Via+Giacomo+Matteotti%2C+11%2C+56124+Pisa+PI%2C+Italy!3m2!1d43.7102769!2d10.412346099999999!5e0!3m2!1sen!2sit!4v1465064871490" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>


