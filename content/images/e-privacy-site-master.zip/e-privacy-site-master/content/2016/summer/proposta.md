Template: event
Title: Proposta Talk
Date: 2015-04-22 10:20
Category: 2016
lang: it
Num: XIX
Year: 2016
slug: e-privacy-XIX-proposta
City: Pisa
Where: Nuova Sala dei Gruppi<br/>Camera dei Deputati<br/>Via Campo Marzio, 78
When: 24-25 Giugno
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: estate
previd: 2015W
prev: e-privacy-XVIII


<iframe src="https://docs.google.com/forms/d/1brHnpw-uHANBVR-0GolsAcLGv1VaWTOlKGymQEemLOE/viewform?embedded=true" width="700" height="900" frameborder="0" marginheight="0" marginwidth="0">Loading...</iframe>

