Template: event
Title: Upload Slides
Date: 2016-09-01 10:20
Category: 2016
lang: it
Num: XX
Year: 2016
slug: e-privacy-XX-upload
City: Roma
XWhere: Nuova Sala dei Gruppi<br/>Camera dei Deputati<br/>Via Campo Marzio, 78
When: 4-5 Novembre
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: autunno
previd: 2016
prev: e-privacy-XX



Usa il [pannello di upload](https://script.google.com/macros/s/AKfycbygv2rEpP-ungBsAFX8bHRilpvzSfQKtHAUr_h9sDVmCvGy50g/exec) per ogni file che vuoi spedire.


