Template: event
Title: Proposta Talk
Date: 2015-09-01 10:20
Category: 2016
lang: it
Num: XX
Year: 2016
slug: e-privacy-XX-proposta
City: Roma
XWhere: Nuova Sala dei Gruppi<br/>Camera dei Deputati<br/>Via Campo Marzio, 78
When: 4-5 Novembre
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: estate
previd: 2016
prev: e-privacy-XIX



<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSeBkXts_tg_nvkwMmhsYWTEFL7WECVZp_LYJkeQ_8TY5uypkg/viewform?embedded=true" width="700" height="900" frameborder="0" marginheight="0" marginwidth="0">Loading...</iframe>


