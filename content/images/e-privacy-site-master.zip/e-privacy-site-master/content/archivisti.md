Template: article
Title: Lavori di archiviazione in corso
Date: 2015-04-22 10:20
Category: generale
lang: it
slug: archivisti
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>



| N      | Edizione                     | Assegnato a |
|--------|------------------------------|-------------|
| I      | e-privacy 2002 I             | marcoc      |
| II     | e-privacy 2003 II            | marcoc      |
| III    | e-privacy 2004 III           | diego       |
| IV     | e-privacy 2005 IV            | marcoc      |
| V      | e-privacy 2006 V             | olga        |
| VI     | e-privacy 2007 VI            | rebecca     |
| VII    | e-privacy 2008 VII           | marcoc      |
| VIII   | e-privacy 2009 VIII          | rebecca     |
| IX     | e-privacy 2010 IX            | graesanus   |
| X      | e-privacy 2011 X             | diego       |
| XI     | e-privacy 2012 spring XI     | rebecca     |
| XII    | e-privacy 2012 autumn XII    | rebecca     |
| XIII   | e-privacy 2013 spring XIII   | rebecca     |
| XIV    | e-privacy 2013 autumn XIV    | enrica      |
| XV     | e-privacy 2014 spring XV     | enrica      |
| XVI    | e-privacy 2014 autumn XVI    | edoardo     |
| XVII   | e-privacy 2015 spring XVII   | enrica      | 
| XVIII  | e-privacy 2015 autumn XVIII  | enrica      | 
| 3.1416 | e-privacy 2016 3.1416        | graesanus   | 
| XIX    | e-privacy 2016 spring XIX    | diego       |
| XX     | e-privacy 2016 autumn XX     | rebecca     |
| XXI    | e-privacy 2017 summer XXI    | enrica      |
| XXII   | e-privacy 2017 autumn XXII   | enrica      |
| XXIII  | e-privacy 2018 summer XXIII  | marcoc      |
| XXIV   | e-privacy 2018 winter XXIV   | marcoc      |
| XXV    | e-privacy 2019 summer XXV    | exedre      |
| XXVI   | e-privacy 2019 winter XXVI   | exedre      |
| XXVII  | e-privacy 2020 summer XXVII  | exedre      |
| XXVIII | e-privacy 2020 autumn XXVIII | exedre      |
| XXIX   | e-privacy 2021 summer XXIX   | exedre      |
| 29e¾   | e-privacy 2021 autumn 29e¾   | exedre      |

Per dare una mano, prendere una edizione e scriverlo alla segreteria, scaricare i file di lavorazione in formato [ODS](images/PWS-YYYYS.ods) o [XLS](images/PWS-YYYYS.xls) e lavorarci seguendo le istruzioni contenute nei file.
