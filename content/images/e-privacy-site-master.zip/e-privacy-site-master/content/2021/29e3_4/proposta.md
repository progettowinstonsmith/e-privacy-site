Template: event
Title: Proposta Talk
Date: 2019-07-15 00:01:00
slug: e-privacy-29e3quarti-proposta
Category: 2021
lang: it
Num: 29e¾
Year: 2021
City: ONLINE
Where: Videoconferenza & Streaming
When: 1-2 ottobre
Season: autumn
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
previd: 2021
prev: e-privacy-XXIX


<script type="text/javascript">
    /** This section is only needed once per page if manually copying **/
    if (typeof MauticSDKLoaded == 'undefined') {
        var MauticSDKLoaded = true;
        var head            = document.getElementsByTagName('head')[0];
        var script          = document.createElement('script');
        script.type         = 'text/javascript';
        script.src          = 'https:/pws.xed.it/media/js/mautic-form.js';
        script.onload       = function() {
            MauticSDK.onLoad();
        };
        head.appendChild(script);
        var MauticDomain = 'https:/pws.xed.it';
        var MauticLang   = {
            'submittingMessage': "Si prega di attendere..."
        }
    }else if (typeof MauticSDK != 'undefined') {
        MauticSDK.onLoad();
    }
</script>


<script type="text/javascript" src="//pws.xed.it/form/generate.js?id=21"></script>
