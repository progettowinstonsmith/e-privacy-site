Status: Draft
Title: Attività sociali
Date: 2021-03-15 00:00:00
Category: 2021
lang: it
Num: XXIX
Year: 2021
slug: e-privacy-XXIX-social
City: ONLINE
Where: Videoconferenza & Streaming
When: 21-22 maggio
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: summer
previd: 2020W
prev: e-privacy-XXVIII
Xnextid: 2016W
Xnext: e-privacy-XVIII

Non è stato ancora comunicato nulla. Torna su questa pagina tra qualche giorno.
