Status: draft
Template: event
Title: Upload slides
Date: 2021-03-15 00:00:00
Category: 2021
lang: it
Num: XXIX
Year: 2021
slug: e-privacy-XXIX-upload
City: ONLINE
Where: Videoconferenza & Streaming
When: 21-22 maggio
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: summer
previd: 2020W
prev: e-privacy-XXVIII


Per caricare le slides è necessario usare [questo form](https://script.google.com/macros/s/AKfycbynQ-F5MLra2McR8pKSR7CbOMr4RaeeUwfMEGL4_Q/exec) con la password fornita ai relatori.
