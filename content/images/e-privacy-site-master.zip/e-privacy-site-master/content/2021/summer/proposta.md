Template: event
Title: Proposta Talk
Date: 2021-03-15 00:00:00
slug: e-privacy-XXIX-proposta
Category: 2021
lang: it
Num: XXIX
Year: 2021
City: ONLINE
Where: Videoconferenza & Streaming
When: 21-22 maggio
Season: summer
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
previd: 2020W
prev: e-privacy-XXVIII



[Spedisci la tua proposta per eprivacy](https://forms.gle/fgsJni2cA9a4g4Vd8)<br/>
[![Spedisci la tua proposta per eprivacy]({static}/images/proposte-XXIX.png "Compila il form per spedire la tua proposta")](https://forms.gle/fgsJni2cA9a4g4Vd8)
