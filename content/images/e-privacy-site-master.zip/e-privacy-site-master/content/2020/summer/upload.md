Template: event
Title: Upload slides
Date: 2020-01-26 12:00:00
Category: 2020
lang: it
Num: XXVII
Year: 2020
slug: e-privacy-XXVII-upload
City: ONLINE
Where: Videoconferenza & Streaming
When: 15-16 maggio
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: spring
previd: 2019W
prev: e-privacy-XXVI


Per caricare le slides è necessario usare [questo form](https://script.google.com/macros/s/AKfycbynQ-F5MLra2McR8pKSR7CbOMr4RaeeUwfMEGL4_Q/exec) con la password fornita ai relatori.
