Status: Draft
Title: Attività sociali
Date: 2020-01-26 12:00:00
Category: 2020
lang: it
Num: XXVII
Year: 2020
slug: e-privacy-XXVII-social
City: ONLINE
Where: Videoconferenza & Streaming
When: 15-16 maggio
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: estate
previd: 2019W
prev: e-privacy-XXIV
Xnextid: 2016W
Xnext: e-privacy-XVIII

Non è stato ancora comunicato nulla. Torna su questa pagina tra qualche giorno.
