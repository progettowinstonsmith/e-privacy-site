Template: event
Title: Proposta Talk
Date: 2020-01-26 13:00:00
slug: e-privacy-XXVII-proposta
Category: 2020
lang: it
Num: XXVII
Year: 2020
City: ONLINE
Where: Videoconferenza & Streaming
When: 15-16 maggio
Season: spring
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
previd: 2019W
prev: e-privacy-XXVI


<iframe src="https://forms.gle/FYmgxAhhiGZAfwco8" width="700" height="800" frameborder="0" marginheight="0" marginwidth="0">Caricamento in corso...</iframe>
