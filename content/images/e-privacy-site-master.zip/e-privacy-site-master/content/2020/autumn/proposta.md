Xstatus: draft
Template: event
Title: Proposta Talk
Date: 2020-08-14 13:00:00
slug: e-privacy-XXVIII-proposta
Category: 2020
lang: it
Num: XXVIII
Year: 2020
City: ONLINE
Where: Videoconferenza & Streaming
When: 2 e 3 ottobre 2020
Season: autumn
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
previd: 2020
prev: e-privacy-XXVII
nextid: 2021
next: e-privacy-XXIX


<iframe src="https://script.google.com/macros/s/AKfycbxjlFugmqfoTdwzBaRxFwK600w7kNBGA1pnzZF97rXL3I5aMGc/exec" width="700" height="800" frameborder="0" marginheight="0" marginwidth="0">Caricamento in corso...</iframe>
