Status: Draft
Title: Attività sociali
Date: 2020-08-13 12:00:00
Category: 2020
lang: it
Num: XXVIII
Year: 2020
slug: e-privacy-XXVIII-social
City: ONLINE
Where: Videoconferenza & Streaming
When: TBD ottobre
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: estate
previd: 2020
prev: e-privacy-XXIV
Xnextid: 2016W
Xnext: e-privacy-XVIII

Non è stato ancora comunicato nulla. Torna su questa pagina tra qualche giorno.
