Template: event
XStatus: draft
Title: Contatti
Date: 2020-08-13 12:00:00
slug: contatti-XXVIII
Category: 2020
lang: it
Num: XXVIII
Year: 2020
City: ONLINE
Where: Videoconferenza & Streaming
When: TBD ottobre
Season: autumn
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>

# Informazioni di contatto

Il convegno *e-privacy* è organizzato da:

- [Progetto Winston Smith](http://pws.winstonsmith.org)
- [Hermes Center for Transparency and Digital Human Rights](http://hermescenter.org)

PER FAVORE CONTATTATECI ESCLUSIVAMENTE VIA EMAIL ALL'INDIRIZZO

[eprivacy@winstonsmith.org](mailto:eprivacy@winstonsmith.org)

Solo i relatori

[cfp-eprivacy@winstonsmith.org](mailto:cfp-eprivacy@winstonsmith.org)



# Seguici online

- Sito web di Winston Smith: [www.winstonsmith.org](http://www.winstonsmith.org)

- Sito web e-privacy: [e-privacy.winstonsmith.org](http://e-privacy.winstonsmith.org)

- Sito web Progetto Winston Smith: [pws.winstonsmith.org](http://pws.winstonsmith.org)

- Sito web Big Brother Awards Italia: [bba.winstonsmith.org](http://bba.winstonsmith.org)

<!-- - Pagina Facebook: [www.facebook.com/events/120596381605441](http://www.facebook.com/events/120596381605441) -->

- Pagina Twitter: [https://twitter.com/eprivacy](https://twitter.com/eprivacy)

- Gruppo Linkedin: [https://www.linkedin.com/groups/1888831/](https://www.linkedin.com/groups/1888831/)

