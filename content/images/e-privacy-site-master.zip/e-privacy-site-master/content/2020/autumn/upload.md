Template: event
Title: Upload slides
Date: 2020-08-13 12:00:00
Category: 2020
lang: it
Num: XXVIII
Year: 2020
slug: e-privacy-XXVIII-upload
City: ONLINE
Where: Videoconferenza & Streaming
When: TBD ottobre
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
Season: autumn
previd: 2020
prev: e-privacy-XXVII
nextid: 2021
next: e-privacy-XXIX


Per caricare le slides è necessario usare [questo form](https://script.google.com/macros/s/AKfycbxjlFugmqfoTdwzBaRxFwK600w7kNBGA1pnzZF97rXL3I5aMGc/exec) con la password fornita ai relatori.
