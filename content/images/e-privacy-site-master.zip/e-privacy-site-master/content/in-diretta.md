Template: article
Title: In diretta
Date: 2020-05-15 15:00
Category: 2020
lang: it
slug: in-diretta
Slogan: <i>"I popoli non dovrebbero temere i propri governi: sono i governi che dovrebbero temere i propri popoli."</i><br/><b>V (da John Basil Barnhill)</b>
css: .title-XXVII { font: 25px arial, sans-serif; text-align: center; }   .subtitle-XXVII { font: 18px arial, sans-serif; text-align: center; .yt { text-align: center; } }

###e-privacy XXVII 2020 - spring edition

<div class="title-XXVII">«Algoritmi, automatismi e predizioni»</div>
<div class="subtitle-XXVII">Giustizia automatica e predittiva, Social Scoring e Smart Cities; poco e troppo "smart" allo stesso tempo?</div>
<br/>


<iframe class='yt' width="560" height="315" src="https://www.youtube-nocookie.com/embed/af0drXpiu_E" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
