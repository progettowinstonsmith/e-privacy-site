# e-privacy-site
e-privacy-site


# Aggiunte

- (2018-05-03) Aggiunto lo script sync-sheet.py che estrae dal foglio Google il programma, gli interventi e le biografie e crea i file md relativi
per questi esistono i nuovi file <>.md.template nelle directory. Per far funzionare questo script è necessario dotarsi di credenziali per i fogli 
google seguendo queste informazioni: https://developers.google.com/sheets/api/quickstart/python



