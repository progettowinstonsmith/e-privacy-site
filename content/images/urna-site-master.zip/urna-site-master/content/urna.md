Title: Urna — il solido ripostiglio di Winston Smith
Date: 2015-04-24 10:20
lang: it

Urna è il repository dei file digitali (audio,video,pdf,ecc…) ed è anche un sito contenente informazioni di lavoro e procedure su come gestire e manutenere tutto il sistema informatico di Winston Smith.

ENTRATE A VOSTRO RISCHIO E PERICOLO.

Tutte le informazioni su questo sito sono altamente instabili e volatili, maneggiare con cura!


## Procedure

### Siti PMGC (Pelican/Markdown/Github/Casellante)

A Winston Smith non piaccono i CMS ed usa solo siti statici. Ha scelto una tecnologia basata sull'integrazione verticale del sistema [Pelican](http://getpelican.org) con il formato testuale [Markdown](http://daringfireball.net/projects/markdown/syntax), il repository [GITHUB](http://github.org/progettowinstonsmith) sul proprio server denominato Casellante. 

- [Attivazione di un sottosistema pelican/markdown](/urna-pmgc-attivazione-di-un-sottosistema-pelicanmarkdown.html)
- [Come modificare una pagina di un sito PMGC](/urna-pgmc-come-modificare-un-sito-winston-smith.html)
- [Come pubblicare un sito PMGC su Casellante](/urna-pgmc-come-pubblicare-un-sito-winston-smith.html)
